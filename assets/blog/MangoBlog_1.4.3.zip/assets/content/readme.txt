A good place to put your blog custom content (images, documents, etc.). 
It is the folder that the administration file explorer will use by default. 